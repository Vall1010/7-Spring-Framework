package com.montrealcollege.soccermatchannotations.beans;

public interface Team {

    String getName();

    void setName(String name);

}
