package com.montrealcollege.soccermatchannotations.config;


import com.montrealcollege.soccermatchannotations.beans.GenericTeam;
import com.montrealcollege.soccermatchannotations.beans.SoccerGame;
import com.montrealcollege.soccermatchannotations.beans.Team;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

@Configuration
public class AppConfig {
    
    @Bean(name = "realmadrid", initMethod = "myInit")
    @Scope("prototype")
    @Lazy
    public Team getHomeTeam() {
        return new GenericTeam("Real Madrid");        
    }
    
    @Bean(name = "juventus")
    public Team getAwayTeam() {
        return new GenericTeam("Juventus");        
    }        
    
    @Bean
    @Scope("prototype")
    public SoccerGame game() {
        SoccerGame baseballGame = new SoccerGame(getHomeTeam(), getAwayTeam());
        return baseballGame;
    }
}
