package com.montrealcollege.soccermatchannotations.beans;

public class GenericTeam implements Team {

    private String name;

    public GenericTeam() {
    }

    public GenericTeam(String nm) {
        name = nm;
    }

    @Override
    public void setName(String nm) {
        name = nm;
    }

    @Override
    public String getName() {
        return name;
    }
}
