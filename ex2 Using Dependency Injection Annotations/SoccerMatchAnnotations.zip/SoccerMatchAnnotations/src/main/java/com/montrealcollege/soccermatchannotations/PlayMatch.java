package com.montrealcollege.soccermatchannotations;

import com.montrealcollege.soccermatchannotations.beans.SoccerGame;
import com.montrealcollege.soccermatchannotations.beans.Team;
import com.montrealcollege.soccermatchannotations.config.AppConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class PlayMatch {

    public static void main(String[] args) {
//        ApplicationContext context = new FileSystemXmlApplicationContext("src/main/resources/beans.xml");
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

        SoccerGame game = context.getBean("game", SoccerGame.class);
        Team realMadrid = context.getBean("realmadrid", Team.class);
        Team juventus = context.getBean("juventus", Team.class);

        game.setHomeTeam(realMadrid);
        game.setAwayTeam(juventus);

        System.out.println(game.toString());
        System.out.println("The winner is " + game.playGame());
    }
}
