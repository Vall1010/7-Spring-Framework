
package com.montrealcollege.exercise3;

import com.montrealcollege.exercise3.entities.Program;
import com.montrealcollege.exercise3.entities.Student;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;


public class Main {
    
    public static void main(String[] args) {
        ApplicationContext context = new FileSystemXmlApplicationContext("src/main/resources/beans.xml");
        
        Program pr = context.getBean("program1", Program.class);
        pr.setName("Web Development");
        
        Student st1 = context.getBean("student1", Student.class);
        Student st2 = context.getBean("student2", Student.class);
        Student st3 = context.getBean("student3", Student.class);
        
        System.out.println("Student 1: " + st1 );
        System.out.println("Student 2: " + st2 );
        System.out.println("Student 3: " + st3 );
    }
    
}
