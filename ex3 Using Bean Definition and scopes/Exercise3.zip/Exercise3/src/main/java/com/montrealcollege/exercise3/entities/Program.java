package com.montrealcollege.exercise3.entities;

public class Program {

    private String name;
    private Integer duration;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    @Override
    public String toString() {
        return "Program{" + "name=" + name + ", duration=" + duration + '}';
    }

}
