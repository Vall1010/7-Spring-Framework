
package com.montrealcollege.springjdbc.dao;

import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.montrealcollege.springjdbc.model.Countries;

@Repository
public class CountriesDAOImpl implements CountriesDAO{
    
    private JdbcTemplate jdbcTemplate;
    
    
    @Autowired
    public void setDataSource(DataSource datasource){
        jdbcTemplate = new JdbcTemplate(datasource);
    }

    @Override
    public List<Countries> getAllCountries() {
        String sql = "Select * from Countries";
        return jdbcTemplate.query(sql, new BeanPropertyRowMapper(Countries.class));
    }
    
}
