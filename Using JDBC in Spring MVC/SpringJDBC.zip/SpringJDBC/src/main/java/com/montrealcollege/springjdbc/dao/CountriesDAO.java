
package com.montrealcollege.springjdbc.dao;

import java.util.List;

import com.montrealcollege.springjdbc.model.Countries;


public interface CountriesDAO {
    
    public List<Countries> getAllCountries();
}
