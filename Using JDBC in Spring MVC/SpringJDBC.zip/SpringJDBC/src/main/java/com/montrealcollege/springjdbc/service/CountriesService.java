
package com.montrealcollege.springjdbc.service;

import com.montrealcollege.springjdbc.dao.CountriesDAO;
import com.montrealcollege.springjdbc.model.Countries;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CountriesService {
    
    @Autowired
    private CountriesDAO countriesDAO;
    
    public List<Countries> getCountries(){
        return countriesDAO.getAllCountries();
    }
}
