
package com.montrealcollege.springjdbc.config;

import java.sql.SQLException;
import javax.sql.DataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.mysql.cj.jdbc.MysqlDataSource;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = "com.montrealcollege")
public class WebConfig {

	@Bean
	public ViewResolver getViewResolver() {
		return new InternalResourceViewResolver("/", ".jsp");
	}

	/* Oracle DataSource */
//    @Bean
//    public DataSource getDataSource() throws SQLException{
//        OracleDataSource dataSource = new OracleDataSource();
//        dataSource.setURL("jdbc:oracle:thin:@//localhost:1521/orcl");
//        dataSource.setUser("hr");
//        dataSource.setPassword("oracle");
//        return dataSource;        
//    }

	@Bean
	public DataSource getDataSource() throws SQLException {
		MysqlDataSource dataSource = new MysqlDataSource();
		dataSource.setURL("jdbc:mysql://localhost:3306/hr");
		dataSource.setUser("root");
		dataSource.setPassword("mYsql123#");
		dataSource.setServerTimezone("UTC");
		return dataSource;
	}
}
