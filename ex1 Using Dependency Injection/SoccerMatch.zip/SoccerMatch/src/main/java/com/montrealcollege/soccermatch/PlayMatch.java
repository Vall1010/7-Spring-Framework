package com.montrealcollege.soccermatch;

import com.montrealcollege.soccermatch.beans.GenericTeam;
import com.montrealcollege.soccermatch.beans.SoccerGame;
import com.montrealcollege.soccermatch.beans.Team;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class PlayMatch {
    
    
    
    public static void main(String[] args) {
        ApplicationContext context = new FileSystemXmlApplicationContext("src/main/resources/beans.xml");

        SoccerGame game = context.getBean("game", SoccerGame.class);
        Team realMadrid = context.getBean("realmadrid", Team.class);
        Team juventus = context.getBean("juventus", Team.class);      
        
        
        juventus.setName("Manchester City");
        
        System.out.println("SoccerGame home Team: " + game.getHomeTeam().getName());
        System.out.println("Juventus object: " + juventus.getName());
        
               
//        System.out.println(game.toString());
//        System.out.println("The winner is "+game.playGame());     
        
    }    
}
