package com.montrealcollege.soccermatch.beans;

public interface Team {

    String getName();

    void setName(String name);

}
