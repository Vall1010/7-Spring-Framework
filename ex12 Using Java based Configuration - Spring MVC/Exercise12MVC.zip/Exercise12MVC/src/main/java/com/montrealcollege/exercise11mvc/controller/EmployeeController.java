package com.montrealcollege.exercise11mvc.controller;

import com.montrealcollege.exercise11mvc.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class EmployeeController {

    @Autowired
    private Employee employee;

    @RequestMapping(path = "/create/{name}", method = RequestMethod.GET)
    public String createEmployee(@PathVariable String name, ModelMap modelMap) {
        employee.setFirstName(name);
        modelMap.addAttribute("message", "Employee created with name " + employee.getFirstName());
        return "hello";
    }

    @RequestMapping(path="/createSalary", method = RequestMethod.GET)
    public String createEmployee(@RequestParam("firstname") String name,
            @RequestParam("lastname") String lastName,
            @RequestParam("salary") Integer salary, ModelMap modelMap) {
        employee.setFirstName(name);
        employee.setLastName(lastName);
        employee.setSalary(salary);

        modelMap.addAttribute("message", "Employee created with name " + employee.getFirstName() + " " + employee.getLastName() + " and salary " + employee.getSalary());
        return "hello";
    }

}
