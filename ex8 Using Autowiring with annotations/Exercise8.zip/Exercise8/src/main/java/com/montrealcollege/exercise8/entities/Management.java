
package com.montrealcollege.exercise8.entities;

import org.springframework.stereotype.Component;

@Component
public class Management implements Department{
    
    private String name = "Management";

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    @Override
	public String toString() {
		return "Department [name=" + name + "]";
	}
    
    
}
