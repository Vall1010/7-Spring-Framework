package com.montrealcollege.exercise8.entities;

import org.springframework.beans.factory.annotation.Autowired;

public class Employee {

    private String completeName;
    private Department department;

    public Employee(String completeName, Department department) {
        this.completeName = completeName;
        this.department = department;
    }

    public String getCompleteName() {
        return completeName;
    }

    public void setCompleteName(String completeName) {
        this.completeName = completeName;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    @Override
    public String toString() {
        return "Employee{" + "completeName=" + completeName + ", department=" + department + '}';
    }

}
