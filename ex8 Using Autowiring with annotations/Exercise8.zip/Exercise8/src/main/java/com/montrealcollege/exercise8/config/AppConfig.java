
package com.montrealcollege.exercise8.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.montrealcollege.exercise8.entities.Department;
import com.montrealcollege.exercise8.entities.Employee;

@Configuration
@ComponentScan(basePackages = "com.montrealcollege")
public class AppConfig {
    
    @Autowired
    @Qualifier("programming")
    public Department dept1;
    
    @Autowired
    @Qualifier("qualityAssurance")
    public Department dept2;
    
    @Autowired
    @Qualifier("management")
    public Department dept3;
    
    @Bean
    public Employee emp1(){
        Employee emp = new Employee("Cristiano Ronaldo",dept1);
        return emp;
    }
    
    @Bean
    public Employee emp2(){
        Employee emp = new Employee("Ronaldo Nazario", dept2);
        return emp;
    }
    
    @Bean
    public Employee emp3(){
        Employee emp = new Employee("Lionel Messi", dept1);
        return emp;
    }
    
    @Bean
    public Employee emp4(){
        Employee emp = new Employee("Pele", dept3);
        return emp;
    }
}
