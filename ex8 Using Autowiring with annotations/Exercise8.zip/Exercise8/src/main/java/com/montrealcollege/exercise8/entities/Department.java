
package com.montrealcollege.exercise8.entities;


public interface Department {
    
    public String getName();
    public void setName(String name);

}
