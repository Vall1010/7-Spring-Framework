
package com.montrealcollege.exercise8;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.montrealcollege.exercise8.config.AppConfig;
import com.montrealcollege.exercise8.entities.Employee;


public class MainClass {
    
    public static void main(String[] args) {
        ApplicationContext context = new 
            AnnotationConfigApplicationContext(AppConfig.class);
        Employee emp1 = context.getBean("emp1",Employee.class);
        Employee emp2 = context.getBean("emp2",Employee.class);
        Employee emp3 = context.getBean("emp3",Employee.class);
        Employee emp4 = context.getBean("emp4",Employee.class);
        System.out.println(emp1);
        System.out.println(emp2);
        System.out.println(emp3);
        System.out.println(emp4);
    }
}
