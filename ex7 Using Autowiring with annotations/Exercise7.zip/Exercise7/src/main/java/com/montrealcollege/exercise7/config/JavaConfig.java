
package com.montrealcollege.exercise7.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.montrealcollege.exercise7.entities.Department;
import com.montrealcollege.exercise7.entities.Employee;
import com.montrealcollege.exercise7.entities.GenericDepartment;

@Configuration
public class JavaConfig {
    
    @Bean
    public Department itProg(){
        return new GenericDepartment("Programming");
    }
    
    @Bean
    @Primary
    public Department qaProg(){
        return new GenericDepartment("Quality Assurance");
    }
    
    @Bean
    public Department mgmProg(){
        return new GenericDepartment("Management");
    }
    
    @Bean
    public Employee emp1(){
        Employee emp = new Employee();
        emp.setCompleteName("Cristiano Ronaldo");
        return emp;
    }
    
    @Bean
    public Employee emp2(){
        Employee emp = new Employee();
        emp.setCompleteName("Ronaldo Nazario");
        return emp;
    }
    
    
}
