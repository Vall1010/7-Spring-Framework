package com.montrealcollege.exercise7.entities;

import org.springframework.beans.factory.annotation.Autowired;

public class Employee {

    private String completeName;
    @Autowired
    private Department department;

    public Employee() {
    }

    public String getCompleteName() {
        return completeName;
    }

    public void setCompleteName(String completeName) {
        this.completeName = completeName;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    @Override
    public String toString() {
        return "Employee{" + "completeName=" + completeName + ", department=" + department + '}';
    }

}
