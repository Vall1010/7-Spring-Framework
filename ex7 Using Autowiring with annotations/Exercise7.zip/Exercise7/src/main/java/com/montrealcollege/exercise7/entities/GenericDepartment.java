
package com.montrealcollege.exercise7.entities;


public class GenericDepartment implements Department{
    
    private String name;

    public GenericDepartment(String nm) {
        this.name = nm;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "GenericDepartment{" + "name=" + name + '}';
    }
    
    
}
