
package com.montrealcollege.exercise7.entities;


public interface Department {
    
    public String getName();
    public void setName(String name);

}
