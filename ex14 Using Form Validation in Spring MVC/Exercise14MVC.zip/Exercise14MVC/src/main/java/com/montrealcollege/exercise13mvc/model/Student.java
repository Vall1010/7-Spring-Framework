package com.montrealcollege.exercise13mvc.model;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

public class Student {

	@NotNull(message = "This field cannot be null")
	private String firstName;
	@NotNull(message = "This field cannot be null")
	private String lastName;
	@NotNull(message = "This field cannot be null")
	@Min(value = 18, message = "The minimum age is 18")
	private Integer age;
	@NotNull(message = "This field cannot be null")
	private String address;
	@NotNull(message = "This field cannot be null")
	private String phoneNumber;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

}
