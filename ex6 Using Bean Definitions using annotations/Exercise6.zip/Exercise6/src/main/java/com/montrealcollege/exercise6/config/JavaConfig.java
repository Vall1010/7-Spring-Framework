package com.montrealcollege.exercise6.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

import com.montrealcollege.exercise6.entities.Program;
import com.montrealcollege.exercise6.entities.Student;

@Configuration
public class JavaConfig {

	@Bean(initMethod = "firstHere")
	@Scope("prototype")
	public Program myProgram() {
		Program program = new Program();
		program.setName("Java Development");
		program.setDuration(12);
		return program;
	}
	
	@Bean
	public Student student1() {
		Student st = new Student();
		st.setFirstName("Ronaldo");
		st.setLastName("Nazario");
		st.setProgram(myProgram());
		return st;
	}
	
	@Bean
	public Student student2() {
		Student st = new Student();
		st.setFirstName("Zinedine");
		st.setLastName("Zidane");
		st.setProgram(myProgram());
		return st;
	}
	
	@Bean
	@Lazy
	public Student student3() {
		Student st = new Student();
		st.setFirstName("Raul");
		st.setLastName("Gonzalez");
		st.setProgram(myProgram());
		return st;
	}
	
	@Bean
	public Student student4() {
		Student st = new Student();
		st.setFirstName("Cristiano");
		st.setLastName("Ronaldo");
		st.setProgram(myProgram());
		return st;
	}
	
	
}
