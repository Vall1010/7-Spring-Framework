package com.montrealcollege.exercise6;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.montrealcollege.exercise6.config.JavaConfig;
import com.montrealcollege.exercise6.entities.Program;
import com.montrealcollege.exercise6.entities.Student;

public class MainClass {
	
	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(JavaConfig.class);
		
		Program program = ctx.getBean("myProgram", Program.class);
		
		Student st1 = ctx.getBean("student1", Student.class);
		Student st2 = ctx.getBean("student2", Student.class);
		Student st3 = ctx.getBean("student3", Student.class);
		Student st4 = ctx.getBean("student4", Student.class);
		
		System.out.println(program);
		System.out.println(st1);
		System.out.println(st2);
		System.out.println(st3);
		System.out.println(st4);
	}

}
